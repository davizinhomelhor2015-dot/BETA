# Backup automático sem configurar nada

## O que fazer

Só isso: copie a pasta `.github` deste pacote pra dentro do seu
repositório do GitHub (juntando com o que já existe lá, se você já tiver
uma pasta `.github`).

Não precisa:
- ❌ saber a senha do Firebase
- ❌ criar token do GitHub
- ❌ ter conta na Vercel
- ❌ configurar nenhuma variável de ambiente

## Como funciona

O arquivo `.github/workflows/backup-cron.yml` já vem pronto com o endereço
do seu Firebase (o mesmo que já está no `index.html`). A cada 15 minutos,
o GitHub roda sozinho o script `.github/scripts/backup.mjs`, que:

1. Olha o horário configurado de cada setor (você configura isso no
   próprio painel, aba **Histórico** → **🗓 Backups Automáticos por Setor**).
2. Quando o horário de algum setor chega, salva os nomes e as fotos do
   dia anterior daquele setor numa pasta `backups/<SETOR>/<DATA>/` dentro
   do próprio repositório.
3. Sobe isso sozinho com um commit — usando o token que o GitHub já
   fornece automaticamente pra cada execução (não precisa criar nada).

## Configurar cada setor

No painel, como administrador:

1. Aba **Histórico** → seção **🗓 Backups Automáticos por Setor**.
2. Clique em **🔗 Repositório do GitHub** e informe `seu-usuario/seu-repositorio`
   (não é senha nem token — só o nome, pra saber onde procurar os backups
   quando você clicar em "Ver" ou "Baixar"). ⚠️ **Isso só funciona pra
   repositórios públicos** — se o seu for privado, os botões "👁 Ver" /
   "⬇ Baixar" / "♻ Restaurar" do painel não conseguem buscar os arquivos
   (mas os backups continuam sendo criados certinho no repositório; você
   só precisaria abrir manualmente pelo site do GitHub).
3. Na tabela de setores, marque **Ativo**, escolha os dias e o horário, e
   clique em **💾 Salvar** na linha de cada um.

## Testar sem esperar o horário

No GitHub, vá na aba **Actions** do seu repositório → clique no workflow
"Backup Automático por Setor" → **Run workflow** → **Run workflow**. Ele
roda na hora, sem precisar esperar os 15 minutos.

## Sobre a precisão do horário

O workflow roda a cada 15 minutos, então o backup de um setor pode sair
até ~15 minutos depois do horário exato configurado (nunca antes) — é a
margem normal desse tipo de agendamento gratuito.
